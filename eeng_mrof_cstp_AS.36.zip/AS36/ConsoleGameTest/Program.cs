using System;

namespace ConsoleGameTest
{
	public class Program
	{
		public static void Main(String[] args){
		}
	}
}

